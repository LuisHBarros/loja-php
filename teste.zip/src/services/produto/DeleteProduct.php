<?php

namespace app\services\produto;

include "../../../vendor/autoload.php";


use app\repositories\ProdutoRepository;

class DeleteProductDTO
{
    public int $id;

    public function __construct(int $id)
    {
        $this->id = $id;
    }
}

class DeleteProduct
{
    private ProdutoRepository $productRepository;

    public function __construct(ProdutoRepository $productRepository)
    {
        $this->productRepository = $productRepository;
    }
    /**
     * Remove um produto baseado no id fornecido
     * @param \app\services\produto\DeleteProductDTO $data
     * @return bool
     */
    public function execute(DeleteProductDTO $data): bool
    {
        try {
            $this->productRepository->remove($data->id);
        } catch (\Exception $e) {
            return false;
        }
        return true;
    }
}
