<?php

namespace app\services\produto;

include "../../../vendor/autoload.php";

use app\repositories\ProdutoRepository;
use app\Entity\Produto;


/**
 * Data Transfer Object for creating a product service
 */
class CreateProductDTO
{
    public string $nome;
    public float $preco;
    public string $descricao;
    public int $estoque;
    /**
     * Summary of __construct
     * @param string $nome
     * @param float $preco
     * @param string $descricao
     * @param int $estoque
     */
    public function __construct(string $nome, float $preco, string $descricao, int $estoque)
    {
        $this->nome = $nome;
        $this->preco = $preco;
        $this->descricao = $descricao;
        $this->estoque = $estoque;
    }
}

class CreateProduct
{
    private ProdutoRepository $productRepository;

    public function __construct(ProdutoRepository $productRepository)
    {
        $this->productRepository = $productRepository;
    }


    /**
     * Cria um novo produto baseado nos dados fornecidos
     * @param \app\services\produto\CreateProductDTO $data
     * @return bool
     */
    public function execute(CreateProductDTO $data): bool
    {
        $product = new Produto(
            null,
            $data->nome,
            $data->preco,
            $data->descricao,
            2,
        );
        try {
            $this->productRepository->add($product);
        } catch (\Exception $e) {
            return false;
        }
        return true;
    }
}
