<?php


namespace app\services\produto;

include "../../../vendor/autoload.php";


use app\Entity\Produto;
use app\repositories\ProdutoRepository;

class GetProductDTO
{
    public int|null $id;
    public string|null $nome;

    public function __construct(int $id = null, string $nome = null)
    {
        $this->id = $id;
        $this->nome = $nome;
    }
}

class GetProduct
{
    private ProdutoRepository $produtoRepository;

    public function __construct(ProdutoRepository $produtoRepository)
    {
        $this->produtoRepository = $produtoRepository;
    }


    /**
     * Devolve um produto baseado no id ou nome fornecido, caso nenhum seja fornecido, devolve todos os produtos
     * @param \app\services\produto\GetProductDTO $data
     * @return array|\app\Entity\Produto
     */
    public function execute(GetProductDTO $data): array| Produto
    {
        if ($data->id !== null) {
            $produto = $this->produtoRepository->findById($data->id);
            return $produto;
        } elseif ($data->nome !== null) {
            $produto = $this->produtoRepository->findByNome($data->nome);
            return $produto;
        }
        return $this->produtoRepository->findAll();
    }
}
