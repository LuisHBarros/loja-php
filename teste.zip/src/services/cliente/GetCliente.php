<?php

namespace app\services\cliente;

use app\Entity\Cliente;
use app\repositories\ClienteRepository;

class GetClienteDTO
{

    public string | null $nome;
    public string | null $email;
    public int | null $id;
}

class GetCliente
{

    private ClienteRepository $clienteRepository;

    public function __construct(ClienteRepository $clienteRepository)
    {
        $this->clienteRepository = $clienteRepository;
    }

    /**
     * Cria um novo cliente baseado nos dados fornecidos
     * @param \app\services\cliente\GetClienteDTO $data
     * @return bool
     */
    public function execute(GetClienteDTO $data): Cliente | array
    {
        if ($data->email !== null) {
            return $this->clienteRepository->findByEmail($data->email);
        }
        if ($data->id !== null) {
            return $this->clienteRepository->findById($data->id);
        }
        return $this->clienteRepository->findAll();
    }
}
