<?php

namespace app\services\cliente;

use app\repositories\ClienteRepository;

class GetClienteDTO
{
    public int $id;

    public function __construct(int $id)
    {
        $this->id = $id;
    }
}

class DeleteCliente
{

    private ClienteRepository $clienteRepository;

    public function __construct(ClienteRepository $clienteRepository)
    {
        $this->clienteRepository = $clienteRepository;
    }

    /**
     * Deleta um cliente baseado no id fornecido
     * @param \app\services\cliente\GetClienteDTO $data
     * @return bool
     */
    public function execute(GetClienteDTO $data): bool
    {

        try {
            $this->clienteRepository->delete($data->id);
        } catch (\Exception $e) {
            return false;
        }
        return true;
    }
}
