<?php

namespace app\services\cliente;

use app\Entity\Cliente;
use app\repositories\ClienteRepository;

class GetClienteDTO
{

    public string $nome;
    public string $email;
    public string $telefone;
    public string $endereco;
}

class CreateCliente
{

    private ClienteRepository $clienteRepository;

    public function __construct(ClienteRepository $clienteRepository)
    {
        $this->clienteRepository = $clienteRepository;
    }

    /**
     * Cria um novo cliente baseado nos dados fornecidos
     * @param \app\services\cliente\GetClienteDTO $data
     * @return bool
     */
    public function execute(GetClienteDTO $data): bool
    {
        $cliente = new Cliente(
            $data->nome,
            $data->email,
            $data->telefone,
            $data->endereco
        );
        try {
            $this->clienteRepository->add($cliente);
        } catch (\Exception $e) {
            return false;
        }
        return true;
    }
}
