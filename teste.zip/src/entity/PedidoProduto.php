<?php

namespace app\Entity;

class PedidoProduto
{
    public int $id_produto;
    public int $id_pedido;
    public float $preco_unitario;
    public int $quantidade;

    /**
     * Summary of __construct
     * @param int $id_produto
     * @param int $id_pedido
     * @param float $preco_unitario
     * @param int $quantidade
     */
    public function __construct(
        int $id_produto,
        int $id_pedido,
        float $preco_unitario,
        int $quantidade
    ) {
        $this->id_produto = $id_produto;
        $this->id_pedido = $id_pedido;
        $this->preco_unitario = $preco_unitario;
        $this->quantidade = $quantidade;
    }
}
