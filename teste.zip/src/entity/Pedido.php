<?php

namespace app\Entity;

class Pedido
{
    public int $id_pedido;
    public int $id_cliente;
    public \DateTime $datapedido;
    public float $total;

    /**
     * Summary of __construct
     * @param int $id_pedido
     * @param int $id_cliente
     * @param DateTime $datapedido
     * @param float $total
     */
    public function __construct(int $id_pedido = null, int $id_cliente, \DateTime $datapedido, float $total)
    {
        $this->id_pedido = $id_pedido;
        $this->id_cliente = $id_cliente;
        $this->datapedido = $datapedido;
        $this->total = $total;
    }
}
