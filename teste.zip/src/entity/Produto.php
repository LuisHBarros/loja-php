<?php

namespace app\Entity;

class Produto
{
    public ?int $id_produto;  // Permite valores `null`
    public string $nome;
    public string $descricao;
    public float $preco;
    public int $estoque;

    /**
     * Summary of __construct
     * @param int|null $id_produto
     * @param string $nome
     * @param string $descricao
     * @param float $preco
     * @param int $estoque
     */
    public function __construct(
        ?int $id_produto = null,  // Permite `null`
        string $nome,
        string $descricao,
        float $preco,
        int $estoque
    ) {
        $this->id_produto = $id_produto;
        $this->nome = $nome;
        $this->descricao = $descricao;
        $this->preco = $preco;
        $this->estoque = $estoque;
    }
}
