<?php

namespace app\Entity;

/**
 * Classe cliente
 */
class Cliente
{
    public int $id_cliente;
    public string $nome;
    public string $email;
    public string $telefone;
    public string $endereco;

    /**
     * Cliente constructor.
     * @param string $nome
     * @param string $email
     * @param string $telefone
     * @param string $endereco
     * @param int $id_cliente
     */
    public function __construct(string $nome, string $email, string $telefone, string $endereco, int $id_cliente = null)
    {
        $this->id_cliente = $id_cliente;
        $this->nome = $nome;
        $this->email = $email;
        $this->telefone = $telefone;
        $this->endereco = $endereco;
    }
}
