<?php

require_once '../vendor/autoload.php';

use app\Entity\Produto;

$produto = new Produto(
    null,
    'Descrição do produto 1',
    'Descrição do produto 1',
    29.99,
    12
);

echo $produto->descricao;
