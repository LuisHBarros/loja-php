<?php

namespace app\repositories;

require_once '../../vendor/autoload.php';

use app\Entity\Produto;

interface ProdutoRepository
{
    /**
     * Adiciona um objeto Product no banco de dados
     * @param Produto $produto
     * @return bool
     */
    function add(Produto $produto): void;
    /**
     * Remove um objeto Product no banco de dados com base no id informado
     * @param int $produto_id
     * @return bool
     */
    function remove(int $produto_id): void;
    /**
     * Busca um objeto Product no banco de dados com base no id informado
     * @param int $id_produto
     * @return void
     */
    function findById(int $id_produto): ?Produto;
    /**
     * Busca um objeto Product no banco de dados com base no nome informado
     * @param string $nome
     * @return void
     */
    function findByNome(string $nome): ?Produto;
    /**
     * Busca todos os objetos Product no banco de dados
     * @return array
     */
    function findAll(): array;
}
