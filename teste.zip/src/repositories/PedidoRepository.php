<?php

namespace app\repositories;

require_once '../../vendor/autoload.php';

use app\Entity\Pedido;

interface PedidoRepository
{
    /**
     * Adiciona um novo pedido ao banco de dados.
     *
     * @param Pedido $pedido
     * @return bool
     */
    public function add(Pedido $pedido): bool;

    /**
     * Atualiza os dados de um pedido.
     *
     * @param Pedido $pedido
     * @return bool
     */
    public function update(Pedido $pedido): bool;

    /**
     * Exclui um pedido pelo ID.
     *
     * @param int $id_pedido
     * @return bool
     */
    public function delete(int $id_pedido): bool;

    /**
     * Busca um pedido pelo ID.
     *
     * @param int $id_pedido
     * @return Pedido|null
     */
    public function findById(int $id_pedido): ?Pedido;

    /**
     * Busca todos os pedidos de um cliente.
     *
     * @param int $id_cliente
     * @return Pedido[]
     */
    public function findByClienteId(int $id_cliente): array;

    /**
     * Retorna todos os pedidos.
     *
     * @return Pedido[]
     */
    public function findAll(): array;
}
