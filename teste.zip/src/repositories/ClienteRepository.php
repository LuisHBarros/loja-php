<?php

namespace app\repositories;

require_once '../../vendor/autoload.php';

use app\Entity\Cliente;


interface ClienteRepository
{
    /**
     * Adiciona um novo cliente ao banco de dados.
     *
     * @param Cliente $cliente
     * @return bool
     */
    public function add(Cliente $cliente): bool;

    /**
     * Atualiza os dados de um cliente.
     *
     * @param Cliente $cliente
     * @return bool
     */
    public function update(Cliente $cliente): bool;

    /**
     * Exclui um cliente pelo ID.
     *
     * @param int $id_cliente
     * @return bool
     */
    public function delete(int $id_cliente): bool;

    /**
     * Busca um cliente pelo ID.
     *
     * @param int $id_cliente
     * @return Cliente|null
     */
    public function findById(int $id_cliente): ?Cliente;

    /**
     * Busca um cliente pelo e-mail.
     *
     * @param string $email
     * @return Cliente|null
     */
    public function findByEmail(string $email): ?Cliente;

    /**
     * Retorna todos os clientes.
     *
     * @return Cliente[]
     */
    public function findAll(): array;
}
