<?php

namespace app\repositories;

require_once '../../vendor/autoload.php';


interface PedidoProdutoRepository
{
    /**
     * Adiciona um produto a um pedido.
     *
     * @param int $id_pedido
     * @param int $id_produto
     * @param int $quantidade
     * @param float $preco_unitario
     * @return bool
     */
    public function addProdutoToPedido(int $id_pedido, int $id_produto, int $quantidade, float $preco_unitario): bool;

    /**
     * Remove um produto de um pedido.
     *
     * @param int $id_pedido
     * @param int $id_produto
     * @return bool
     */
    public function removeProdutoFromPedido(int $id_pedido, int $id_produto): bool;

    /**
     * Atualiza a quantidade de um produto em um pedido.
     *
     * @param int $id_pedido
     * @param int $id_produto
     * @param int $quantidade
     * @return bool
     */
    public function updateQuantidade(int $id_pedido, int $id_produto, int $quantidade): bool;

    /**
     * Busca todos os produtos de um pedido específico.
     *
     * @param int $id_pedido
     * @return array
     */
    public function findProdutosByPedidoId(int $id_pedido): array;

    /**
     * Busca todos os pedidos que contêm um determinado produto.
     *
     * @param int $id_produto
     * @return array
     */
    public function findPedidosByProdutoId(int $id_produto): array;
}
